class calc
    {
      void main()
        {
          int i=0;
          while(i<5)
            {
              System.out.println(i);
              }
         }
    }